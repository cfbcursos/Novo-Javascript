let n1=20

let res = n1 >> 2

console.log(res)