let num1=10
let num2=5
let num3=10

console.log(num1 != num3)

//  >  >=  <  <=  ==  !=
