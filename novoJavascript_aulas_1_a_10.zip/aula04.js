let num1=0,num2=0,res=0

num1=10
num1/=2 

console.log(num1)
