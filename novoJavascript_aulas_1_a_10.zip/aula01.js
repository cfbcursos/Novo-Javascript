console.log("Esta linha está comentada")
console.log("Alô Mundo")
console.log("Fim")