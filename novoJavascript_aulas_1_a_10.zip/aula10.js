let st="I"
res=(st == "A" ? "Ativo" : "Inativo")
console.log(res)

//0 = False
//1 = True

// Teste lógico ? se verdadeiro : se falso

