"use strict"

let nome="Bruno"
console.log("CFB Cursos")
console.log(nome)
console.log("Nome: " + nome)