let n1=10
let n2=20

console.log(n1 + "" + n2)

