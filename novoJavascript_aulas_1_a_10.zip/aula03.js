"use strict"

let nome="Bruno"
nome="CFB Cursos"
nome=10

const curso="Javascript"

curso=

console.log(curso)

