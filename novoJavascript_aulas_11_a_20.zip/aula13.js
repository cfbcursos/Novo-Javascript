let energia=100
let clima="chovendo"

if(energia > 70 && clima=="sol"){
    console.log("Vou a praia")
}else{
    console.log("Vou ao cinema")
}

console.log("Fim do programa")