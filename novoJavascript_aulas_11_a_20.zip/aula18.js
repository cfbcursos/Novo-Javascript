let n=10
do{
    console.log("CFB Cursos")
    n++
}while(n<10)
console.log("Fim do programa")