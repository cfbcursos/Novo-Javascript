function mudarTexto(){
    let d1=document.getElementById("d1")
    let d2=document.getElementById("d2")
    let d3=document.getElementById("d3")
    d1.innerHTML="CFB Cursos"
    d2.innerHTML="CFB Cursos"
    d3.innerHTML="CFB Cursos"
}
